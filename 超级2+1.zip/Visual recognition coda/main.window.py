import sys
import cv2
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QPushButton, QStatusBar, QFrame, QSplitter)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QImage, QPixmap, QFont
from .camera_thread import CameraThread

class StrawberrySortingMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.init_camera()

    def init_ui(self):
        # 窗体基础配置
        self.setWindowTitle("基于RK 3588边缘AI草莓智能分选与运输系统")
        self.setMinimumSize(1280, 720)  # 适配RK3588常见显示分辨率

        # 中心部件布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 标题栏
        title_label = QLabel("基于RK 3588边缘AI草莓智能分选与运输系统")
        title_font = QFont("微软雅黑", 18, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("padding: 10px; background-color: #2E86AB; color: white;")
        main_layout.addWidget(title_label)

        # 核心内容区（摄像头显示 + 控制区）
        content_splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(content_splitter)

        # 摄像头显示区域
        self.camera_label = QLabel()
        self.camera_label.setMinimumSize(800, 600)
        self.camera_label.setStyleSheet("border: 2px solid #000;")
        self.camera_label.setAlignment(Qt.AlignCenter)
        content_splitter.addWidget(self.camera_label)

        # 右侧控制区域
        control_widget = QWidget()
        control_layout = QVBoxLayout(control_widget)
        control_layout.setAlignment(Qt.AlignTop)

        # 功能按钮
        self.start_btn = QPushButton("启动识别/运输")
        self.stop_btn = QPushButton("停止识别/运输")
        self.exit_btn = QPushButton("退出系统")
        btn_style = "padding: 10px; font-size: 14px; margin: 5px;"
        self.start_btn.setStyleSheet(btn_style + "background-color: #28A745; color: white;")
        self.stop_btn.setStyleSheet(btn_style + "background-color: #DC3545; color: white;")
        self.exit_btn.setStyleSheet(btn_style + "background-color: #6C757D; color: white;")

        # 状态显示
        self.status_label = QLabel("系统状态：未启动")
        self.status_label.setStyleSheet("padding: 8px; font-size: 14px; color: #DC3545;")

        # 添加控件到控制区
        control_layout.addWidget(self.start_btn)
        control_layout.addWidget(self.stop_btn)
        control_layout.addWidget(self.exit_btn)
        control_layout.addWidget(self.status_label)
        content_splitter.addWidget(control_widget)

        # 状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("RK3588边缘AI平台已就绪 | 摄像头未连接", 0)

        # 按钮绑定事件
        self.start_btn.clicked.connect(self.start_system)
        self.stop_btn.clicked.connect(self.stop_system)
        self.exit_btn.clicked.connect(self.close)

    def init_camera(self):
        # 初始化摄像头线程（RK3588支持USB/CSI摄像头）
        self.camera_thread = CameraThread(camera_idx=0)  # 0为默认摄像头，可根据RK3588配置调整
        self.camera_thread.frame_signal.connect(self.update_camera_frame)
        self.camera_thread.error_signal.connect(self.show_camera_error)

    def start_system(self):
        """启动识别和运输系统"""
        self.camera_thread.start()
        self.status_label.setText("系统状态：运行中（识别+运输）")
        self.status_label.setStyleSheet("padding: 8px; font-size: 14px; color: #28A745;")
        self.status_bar.showMessage("RK3588 AI推理已启动 | 摄像头已连接 | 运输系统运行中", 0)

    def stop_system(self):
        """停止识别和运输系统"""
        self.camera_thread.stop()
        self.camera_label.clear()
        self.camera_label.setText("摄像头已停止")
        self.status_label.setText("系统状态：已停止")
        self.status_label.setStyleSheet("padding: 8px; font-size: 14px; color: #DC3545;")
        self.status_bar.showMessage("RK3588 AI推理已停止 | 摄像头已断开 | 运输系统已停止", 0)

    def update_camera_frame(self, frame):
        """更新摄像头显示帧（叠加AI识别结果）"""
        # 转换OpenCV帧为Qt显示格式
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        # 自适应缩放显示
        scaled_pixmap = QPixmap.fromImage(qt_image).scaled(
            self.camera_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self.camera_label.setPixmap(scaled_pixmap)

    def show_camera_error(self, error_msg):
        """显示摄像头错误"""
        self.camera_label.setText(f"摄像头异常：{error_msg}")
        self.status_bar.showMessage(f"错误：{error_msg}", 0)

    def closeEvent(self, event):
        """窗体关闭时释放资源"""
        self.stop_system()
        event.accept()

if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    window = StrawberrySortingMainWindow()
    window.show()
    sys.exit(app.exec_())

             