#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
串口发送程序 - 草莓检测联动模式
设备号：/dev/ttyS9
波特率：9600
通讯协议：报头 AA，报尾 55，数据 11
触发条件：检测到2个好草莓时，每隔1秒发送一次
"""

import serial
import time
from datetime import datetime


class SerialSenderForStrawberry:
    def __init__(self, port='/dev/ttyS9', baudrate=9600):
        """
        初始化串口发送器
        :param port: 串口端口号
        :param baudrate: 波特率
        """
        self.port = port
        self.baudrate = baudrate
        self.serial_port = None
        
        # 协议常量
        self.HEADER = 0xAA
        self.DATA = 0x10
        self.TAIL = 0x55
        
        # 状态变量
        self.good_strawberry_count = 0
        self.is_sending = False
        self.send_interval = 1.0  # 发送间隔（秒）
        
    def open_serial(self):
        """打开串口"""
        try:
            self.serial_port = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1
            )

            print(f"[{datetime.now().strftime('%H:%M:%S')}] 串口 {self.port} 打开成功")
            return True
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 打开串口失败：{e}")
            return False
    
    def close_serial(self):
        """关闭串口"""
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 串口已关闭")
    
    def create_packet(self):
        """
        创建数据包
        :return: 完整的数据包
        """
        packet = bytes([self.HEADER, self.DATA, self.TAIL])
        return packet
    
    def send_once(self):
        """
        发送一次数据
        :return: 是否发送成功
        """
        if not self.serial_port or not self.serial_port.is_open:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] 串口未打开")
            return False
        
        try:
            packet = self.create_packet()
            self.serial_port.write(packet)
            self.serial_port.flush()
            timestamp = datetime.now().strftime('%H:%M:%S')
            print(f"[{timestamp}] 发送数据：AA 11 55")
            return True
        except Exception as e:
            timestamp = datetime.now().strftime('%H:%M:%S')
            print(f"[{timestamp}] 发送失败：{e}")
            return False
    
    def update_good_strawberry_count(self, count):
        """
        更新好草莓数量
        :param count: 当前检测到的好草莓数量
        """
        old_count = self.good_strawberry_count
        self.good_strawberry_count = count
        
        # 当数量达到2个时，开始发送
        if count >= 2 and not self.is_sending:
            print(f"\n{'='*60}")
            print(f"检测到 {count} 个好草莓，开始定时发送...")
            print(f"{'='*60}")
            self.is_sending = True
            self.start_sending()
        
        # 当数量低于2个时，停止发送
        elif count < 2 and self.is_sending:
            print(f"\n{'='*60}")
            print(f"好草莓数量降至 {count} 个，停止发送")
            print(f"{'='*60}")
            self.is_sending = False
    
    def start_sending(self):
        """开始定时发送"""
        if not self.open_serial():
            return
        
        print(f"\n开始定时发送...")
        print(f"发送间隔：{self.send_interval} 秒")
        print(f"发送内容：AA 11 55")
        print("-" * 60)
        
        send_count = 0
        while self.is_sending:
            try:
                send_count += 1
                success = self.send_once()
                if not success:
                    print("发送失败，尝试重新连接串口...")
                    self.close_serial()
                    time.sleep(1)
                    if not self.open_serial():
                        print("重新连接失败，停止发送")
                        self.is_sending = False
                        break
                
                # 等待指定间隔
                time.sleep(self.send_interval)
                    
            except KeyboardInterrupt:
                print("\n用户中断发送")
                self.is_sending = False
                break
            except Exception as e:
                print(f"发送异常：{e}")
                self.is_sending = False
                break
        
        print("-" * 60)
        print(f"发送结束！共发送 {send_count} 次")
        self.close_serial()
    
    def stop_sending(self):
        """停止发送"""
        self.is_sending = False


def main():
    """主函数 - 测试模式"""
    print("=" * 60)
    print("串口通信程序 - 草莓检测联动模式")
    print("=" * 60)
    print("设备号：/dev/ttyS9")
    print("波特率：9600")
    print("通讯协议：报头 AA，报尾 55，数据 11")
    print("触发条件：检测到2个好草莓时，每隔1秒发送一次")
    print("=" * 60)
    
    # 创建发送器实例
    sender = SerialSenderForStrawberry(port='/dev/ttyS9', baudrate=9600)
    
    try:
        # 模拟检测过程
        print("\n模拟草莓检测过程...")
        print("按回车键增加好草莓数量，输入 'q' 退出\n")
        
        while True:
            user_input = input(f"当前好草莓数量: {sender.good_strawberry_count} | 请输入操作 (回车增加/q退出): ")
            
            if user_input.lower() == 'q':
                print("退出程序")
                break
            
            # 每次回车增加一个好草莓计数
            sender.good_strawberry_count += 1
            sender.update_good_strawberry_count(sender.good_strawberry_count)
            
    except KeyboardInterrupt:
        print("\n\n程序被用户中断")
    finally:
        sender.stop_sending()
        sender.close_serial()
        print("程序已结束")


if __name__ == "__main__":
    main()
