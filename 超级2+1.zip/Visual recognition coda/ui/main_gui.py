import cv2
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QPushButton, QTextEdit, QSizePolicy, QTabWidget, QSpinBox)
from PyQt5.QtCore import Qt, pyqtSignal, QObject, QTimer
from PyQt5.QtGui import QImage, QPixmap, QFont
from ui.camera_worker import CameraThread
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from duoji import ServoController
from serial_send_strawberry import SerialSenderForStrawberry


class ServoControlSignal(QObject):
    """用于线程安全地发送舵机控制日志信号"""
    log_signal = pyqtSignal(str)


class SerialControlSignal(QObject):
    """用于线程安全地控制串口发送信号"""
    start_signal = pyqtSignal()
    stop_signal = pyqtSignal()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.camera_thread = None
        self.servo_controller = None
        self.serial_sender = None  # 串口发送器
        self.current_angle = 0
        self.last_detection_time = 0  # 上次检测时间，用于防抖
        self.detection_cooldown = 1.0  # 检测冷却时间（秒），避免频繁触发
        self.good_strawberry_count = 0  # 好草莓计数
        self.servo_signal = ServoControlSignal()  # 创建舵机控制信号对象
        self.servo_signal.log_signal.connect(self.append_log)  # 连接信号到日志方法
        
        # 串口控制信号（用于跨线程安全调用）
        self.serial_control_signal = SerialControlSignal()
        self.serial_control_signal.start_signal.connect(self.start_serial_sending)
        self.serial_control_signal.stop_signal.connect(self.stop_serial_sending)
        
        # 串口定时发送相关
        self.serial_timer = QTimer()  # 定时器用于周期性发送串口数据
        self.serial_timer.timeout.connect(self.send_serial_periodically)
        self.serial_send_count = 0  # 串口发送计数器
        self.serial_max_count = 10  # 最大发送次数
        self.serial_send_interval = 3000  # 发送间隔（毫秒），3秒
        
        self.init_ui()

    def init_ui(self):
        # 主窗口设置
        self.setWindowTitle("基于RK 3588边缘AI草莓智能分选与运输系统")
        self.resize(1200, 700)

        # 中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 1. 顶部大标题
        title_label = QLabel("基于RK 3588边缘AI草莓智能分选与运输系统")
        title_font = QFont("SimHei", 20, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("background:#2980b9; color:white; padding:12px;")
        main_layout.addWidget(title_label)

        # 2. 创建标签页控件
        self.tab_widget = QTabWidget()
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #bdc3c7;
            }
            QTabBar::tab {
                background: #ecf0f1;
                color: #2c3e50;
                padding: 10px 20px;
                margin-right: 2px;
                font-size: 14px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background: #3498db;
                color: white;
            }
            QTabBar::tab:hover {
                background: #85c1e9;
            }
        """)
        
        # 创建两个标签页
        self.page_detection = self.create_detection_page()
        self.page_servo = self.create_servo_page()
        
        self.tab_widget.addTab(self.page_detection, "📷 AI检测页面")
        self.tab_widget.addTab(self.page_servo, "⚙️ 舵机控制页面")
        
        main_layout.addWidget(self.tab_widget)

        # 绑定按钮事件
        self.btn_start.clicked.connect(self.start_detect)
        self.btn_stop.clicked.connect(self.stop_detect)
        self.btn_exit.clicked.connect(self.close)
        
        # 舵机控制按钮事件
        self.btn_servo_init.clicked.connect(self.init_servo)
        self.btn_servo_custom.clicked.connect(self.move_servo_custom)

    def create_detection_page(self):
        """创建AI检测页面"""
        page = QWidget()
        layout = QHBoxLayout(page)
        
        # 左侧：摄像头显示区
        self.video_label = QLabel("等待启动摄像头...")
        self.video_label.setMinimumSize(800, 500)
        self.video_label.setStyleSheet("border:2px solid #34495e; background:#ecf0f1;")
        self.video_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.video_label)
        
        # 右侧：按钮 + 日志
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # 功能按钮
        self.btn_start = QPushButton("启动检测")
        self.btn_stop = QPushButton("停止检测")
        self.btn_exit = QPushButton("退出系统")
        self.btn_start.setStyleSheet("background:#27ae60; color:white; font-size:14px; padding:8px;")
        self.btn_stop.setStyleSheet("background:#e74c3c; color:white; font-size:14px; padding:8px;")
        self.btn_exit.setStyleSheet("background:#7f8c8d; color:white; font-size:14px; padding:8px;")
        
        right_layout.addWidget(self.btn_start)
        right_layout.addWidget(self.btn_stop)
        right_layout.addWidget(self.btn_exit)
        
        # 日志输出框
        self.log_edit = QTextEdit()
        self.log_edit.setPlaceholderText("系统日志输出区域...")
        self.log_edit.setReadOnly(True)
        self.log_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_layout.addWidget(QLabel("系统日志:"))
        right_layout.addWidget(self.log_edit)
        
        layout.addWidget(right_widget)
        return page
    
    def create_servo_page(self):
        """创建舵机控制页面"""
        page = QWidget()
        layout = QVBoxLayout(page)
        
        # 标题
        servo_title = QLabel("舵机控制系统")
        servo_title.setFont(QFont("SimHei", 16, QFont.Bold))
        servo_title.setAlignment(Qt.AlignCenter)
        servo_title.setStyleSheet("padding: 10px; background: #34495e; color: white;")
        layout.addWidget(servo_title)
        
        # 舵机状态显示区
        status_group = QWidget()
        status_layout = QVBoxLayout(status_group)
        
        self.servo_status_label = QLabel("舵机状态: 未初始化")
        self.servo_status_label.setFont(QFont("SimHei", 12))
        self.servo_status_label.setAlignment(Qt.AlignCenter)
        self.servo_status_label.setStyleSheet("padding: 15px; background: #ecf0f1; border: 2px solid #bdc3c7;")
        status_layout.addWidget(self.servo_status_label)
        
        self.servo_angle_label = QLabel("当前角度: --")
        self.servo_angle_label.setFont(QFont("SimHei", 12))
        self.servo_angle_label.setAlignment(Qt.AlignCenter)
        self.servo_angle_label.setStyleSheet("padding: 15px; background: #ecf0f1; border: 2px solid #bdc3c7;")
        status_layout.addWidget(self.servo_angle_label)
        
        layout.addWidget(status_group)
        
        # 舵机控制按钮区
        control_group = QWidget()
        control_layout = QVBoxLayout(control_group)
        
        # 初始化按钮
        self.btn_servo_init = QPushButton("初始化舵机")
        self.btn_servo_init.setStyleSheet("background:#3498db; color:white; font-size:14px; padding:10px; font-weight:bold;")
        control_layout.addWidget(self.btn_servo_init)
        
        # 自定义角度控制
        custom_layout = QHBoxLayout()
        custom_label = QLabel("设置角度:")
        custom_label.setFont(QFont("SimHei", 12))
        self.spin_servo_angle = QSpinBox()
        self.spin_servo_angle.setRange(0, 180)
        self.spin_servo_angle.setValue(0)
        self.spin_servo_angle.setFont(QFont("SimHei", 12))
        self.spin_servo_angle.setMinimumHeight(40)
        self.spin_servo_angle.setStyleSheet("padding: 5px; font-size: 14px;")
        self.btn_servo_custom = QPushButton("转动到指定角度")
        self.btn_servo_custom.setFont(QFont("SimHei", 12, QFont.Bold))
        self.btn_servo_custom.setMinimumHeight(40)
        self.btn_servo_custom.setStyleSheet("background:#e67e22; color:white; padding:10px;")
        
        custom_layout.addWidget(custom_label)
        custom_layout.addWidget(self.spin_servo_angle)
        custom_layout.addWidget(self.btn_servo_custom)
        control_layout.addLayout(custom_layout)
        
        layout.addWidget(control_group)
        
        # 说明文本
        info_label = QLabel(
            "使用说明:\n"
            "• 0° - 正常位置，好草莓通过\n"
            "• 45° - 剔除位置，坏草莓转向\n"
            "• 90° - 测试位置，用于调试\n"
            "• 每次动作后自动复位到0°"
        )
        info_label.setFont(QFont("SimHei", 10))
        info_label.setStyleSheet("padding: 15px; background: #fff3cd; border: 2px solid #ffc107; color: #856404;")
        info_label.setAlignment(Qt.AlignLeft)
        layout.addWidget(info_label)
        
        layout.addStretch()
        return page
    
    def init_servo(self):
        """初始化舵机"""
        try:
            self.servo_status_label.setText("舵机状态: 初始化中...")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #fff3cd; border: 2px solid #ffc107;")
            self.log_edit.append(">>> 正在初始化舵机...")
            
            # 创建舵机控制器实例
            self.servo_controller = ServoController(chip_num=0, period_ns=20000000)
            
            # 检查PWM设备
            if not self.servo_controller.check_pwm_exists():
                error_msg = f"❌ PWM设备不存在: {self.servo_controller.pwm_path}\n请确认:\n1. 系统支持PWM功能\n2. 以root权限运行程序"
                self.log_edit.append(error_msg)
                self.servo_status_label.setText("舵机状态: 初始化失败")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
                return
            
            # 先尝试清理旧的PWM通道（如果存在）
            import os
            pwm0_path = "/sys/class/pwm/pwmchip0/pwm0"
            if os.path.exists(pwm0_path):
                self.log_edit.append("⚠️ 检测到未释放的PWM通道，尝试清理...")
                try:
                    # 先禁用
                    with open(os.path.join(pwm0_path, "enable"), 'w') as f:
                        f.write('0')
                    # 再unexport
                    with open("/sys/class/pwm/pwmchip0/unexport", 'w') as f:
                        f.write('0')
                    import time
                    time.sleep(0.5)
                    self.log_edit.append("✓ 旧PWM通道已清理")
                except Exception as e:
                    self.log_edit.append(f"⚠️ 清理旧通道失败: {e}，继续尝试...")
            
            # 导出PWM通道（带重试机制）
            export_success = False
            for retry in range(3):
                if self.servo_controller.export_pwm():
                    export_success = True
                    break
                else:
                    self.log_edit.append(f"⚠️ 导出PWM通道失败 (尝试 {retry+1}/3)，等待1秒后重试...")
                    import time
                    time.sleep(1)
            
            if not export_success:
                self.log_edit.append("❌ 导出PWM通道失败，请检查是否有其他程序占用PWM设备")
                self.servo_status_label.setText("舵机状态: 初始化失败")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
                return
            
            # 设置周期
            if not self.servo_controller.set_period():
                self.log_edit.append("❌ 设置PWM周期失败")
                self.servo_status_label.setText("舵机状态: 初始化失败")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
                return
            
            # 启用PWM
            if not self.servo_controller.enable_pwm(True):
                self.log_edit.append("❌ 启用PWM失败")
                self.servo_status_label.setText("舵机状态: 初始化失败")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
                return
            
            # 初始化成功，移动到0度
            self.log_edit.append(">>> 将舵机归位到0°...")
            success = self.servo_controller.move_to_angle(0, delay=0.5)
            if success:
                self.current_angle = 0
                self.servo_status_label.setText("舵机状态: 已就绪")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #d4edda; border: 2px solid #28a745;")
                self.servo_angle_label.setText("当前角度: 0°")
                self.log_edit.append("✓ 舵机初始化成功，已归位到0°")
            else:
                self.log_edit.append("⚠️ 舵机初始化完成，但归位失败，请检查硬件连接")
                self.servo_status_label.setText("舵机状态: 部分成功")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #fff3cd; border: 2px solid #ffc107;")
        except PermissionError as e:
            error_msg = f"❌ 权限错误: {str(e)}\n请以root权限运行程序: sudo python3 main.py"
            self.log_edit.append(error_msg)
            self.servo_status_label.setText("舵机状态: 权限错误")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
        except Exception as e:
            import traceback
            error_msg = f"❌ 舵机初始化异常: {str(e)}\n{traceback.format_exc()}"
            self.log_edit.append(error_msg)
            self.servo_status_label.setText("舵机状态: 初始化失败")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
    
    def move_servo(self, angle):
        """控制舵机转动到指定角度"""
        if self.servo_controller is None:
            self.log_edit.append("❌ 请先点击【初始化舵机】按钮！")
            self.servo_status_label.setText("舵机状态: 未初始化")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
            return False
        
        try:
            self.log_edit.append(f">>> 舵机转动到 {angle}°")
            self.servo_status_label.setText(f"舵机状态: 运动中 ({angle}°)")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #fff3cd; border: 2px solid #ffc107;")
            
            # 给舵机足够的延时时间来完成动作
            success = self.servo_controller.move_to_angle(angle, delay=0.5)
            
            if success:
                self.current_angle = angle
                self.servo_angle_label.setText(f"当前角度: {angle}°")
                self.spin_servo_angle.setValue(angle)
                self.servo_status_label.setText("舵机状态: 已就绪")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #d4edda; border: 2px solid #28a745;")
                self.log_edit.append(f"✓ 舵机已到达 {angle}°")
                return True
            else:
                self.log_edit.append(f"❌ 舵机移动到 {angle}° 失败，请检查硬件连接")
                self.servo_status_label.setText("舵机状态: 移动失败")
                self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
                return False
        except Exception as e:
            self.log_edit.append(f"❌ 舵机控制异常: {str(e)}")
            import traceback
            self.log_edit.append(f"详细错误: {traceback.format_exc()}")
            self.servo_status_label.setText("舵机状态: 控制异常")
            self.servo_status_label.setStyleSheet("padding: 15px; background: #f8d7da; border: 2px solid #dc3545;")
            return False
    
    def move_servo_custom(self):
        """控制舵机转动到自定义角度"""
        angle = self.spin_servo_angle.value()
        self.move_servo(angle)

    def start_serial_sending(self):
        """启动串口定时发送（每隔3秒发送AA 10 55，共发送10次）"""
        if self.serial_sender is None:
            try:
                self.serial_sender = SerialSenderForStrawberry(port='/dev/ttyS9', baudrate=9600)
                self.log_edit.append(">>> 串口发送器初始化成功 (/dev/ttyS9, 9600)")
            except Exception as e:
                self.log_edit.append(f"⚠️ 串口发送器初始化失败: {e}")
                return False
            
        # 打开串口（如果还未打开）
        if not self.serial_sender.serial_port or not self.serial_sender.serial_port.is_open:
            self.log_edit.append(">>> 正在打开串口...")
            if not self.serial_sender.open_serial():
                self.log_edit.append("❌ 串口打开失败，无法启动定时发送")
                return False
            self.log_edit.append("✓ 串口已成功打开")
            
        # 重置计数器
        self.serial_send_count = 0
        self.serial_max_count = 5  # 修改为5次
            
        # 启动定时器，每隔3秒触发一次
        self.serial_timer.start(self.serial_send_interval)  # 3000毫秒 = 3秒
        self.log_edit.append(f">>> 启动串口定时发送：每隔{self.serial_send_interval//1000}秒发送 AA 11 55，共{self.serial_max_count}次")
        return True
    
    def stop_serial_sending(self):
        """停止串口定时发送"""
        self.serial_timer.stop()
        self.log_edit.append(f">>> 串口定时发送已停止（共发送 {self.serial_send_count} 次）")
    
    def send_serial_periodically(self):
        """定时器触发的串口发送函数"""
        if self.serial_send_count >= self.serial_max_count:
            self.stop_serial_sending()
            self.log_edit.append("✅ 串口发送完成")
            return
        
        try:
            if self.serial_sender and self.serial_sender.serial_port and self.serial_sender.serial_port.is_open:
                # 创建并发送数据包：AA 11 55
                packet = bytes([0xAA, 0x11, 0x55])
                self.serial_sender.serial_port.write(packet)
                self.serial_sender.serial_port.flush()
                
                self.serial_send_count += 1
                from datetime import datetime
                timestamp = datetime.now().strftime('%H:%M:%S')
                self.log_edit.append(f"[{timestamp}] 第 {self.serial_send_count}/{self.serial_max_count} 次发送：AA 11 55")
            else:
                self.log_edit.append("⚠️ 串口未打开，尝试重新打开...")
                if self.serial_sender.open_serial():
                    self.send_serial_periodically()  # 重新尝试发送
                else:
                    self.stop_serial_sending()
        except Exception as e:
            self.log_edit.append(f"❌ 串口发送失败: {e}")
            self.stop_serial_sending()

    def start_detect(self):
        """启动摄像头+AI检测"""
        if self.camera_thread and self.camera_thread.isRunning():
            self.log_edit.append("系统已在运行中，请勿重复启动")
            return
        
        # 初始化串口发送器（但不启动定时发送）
        if self.serial_sender is None:
            try:
                self.serial_sender = SerialSenderForStrawberry(port='/dev/ttyS9', baudrate=9600)
                self.log_edit.append(">>> 串口发送器初始化成功 (/dev/ttyS9, 9600)")
            except Exception as e:
                self.log_edit.append(f"⚠️ 串口发送器初始化失败: {e}")
                self.log_edit.append("将继续运行，但不会发送串口数据")
        
        self.camera_thread = CameraThread()
        self.camera_thread.frame_signal.connect(self.update_frame)
        self.camera_thread.log_signal.connect(self.append_log)
        self.camera_thread.detection_signal.connect(self.handle_detection_result)  # 连接检测结果信号
        self.camera_thread.start()
        self.log_edit.append(">>> 开始启动AI检测系统...")

    def stop_detect(self):
        """停止检测"""
        # 停止串口定时发送
        self.stop_serial_sending()
        
        if self.camera_thread:
            self.camera_thread.stop()
            self.camera_thread = None
            self.video_label.setText("摄像头已停止")
            self.log_edit.append(">>> 已停止AI检测")

    def update_frame(self, frame):
        """更新摄像头画面"""
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        q_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pix = QPixmap.fromImage(q_img).scaled(self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.video_label.setPixmap(pix)

    def append_log(self, text):
        """追加日志"""
        self.log_edit.append(text)
    
    def handle_detection_result(self, category, confidence):
        """处理检测结果，控制舵机联动"""
        import time
        import threading
        current_time = time.time()
        
        # 检查是否在冷却时间内，避免频繁触发
        if current_time - self.last_detection_time < self.detection_cooldown:
            return
        
        # 检查舵机是否已初始化
        if self.servo_controller is None:
            # 自动初始化舵机（如果未初始化）
            self.servo_signal.log_signal.emit("⚠️ 舵机未初始化，正在自动初始化...")
            self.init_servo()
            if self.servo_controller is None:
                self.servo_signal.log_signal.emit("❌ 舵机初始化失败，无法进行联动控制")
                return
        
        # 使用线程异步处理舵机控制，避免阻塞UI
        def servo_control_task():
            try:
                self.servo_signal.log_signal.emit(f"🔍 开始处理检测结果: {category}, 置信度: {confidence:.2f}")
                self.servo_signal.log_signal.emit(f"🔍 当前舵机角度: {self.current_angle}°")
                
                if category == "goodstrawberry":
                    # 检测到好草莓，增加计数
                    self.good_strawberry_count += 1
                    self.servo_signal.log_signal.emit(f"🍓 检测到好草莓 (置信度: {confidence:.2f}) → 好草莓总数: {self.good_strawberry_count}")
                    
                    # 检查是否达到4个好草莓，如果是则启动串口发送
                    if self.good_strawberry_count >= 4:
                        self.servo_signal.log_signal.emit(f"✅ 好草莓数量达到 {self.good_strawberry_count} 个，启动串口定时发送...")
                        # 通过信号在主线程中启动串口定时发送（避免跨线程问题）
                        self.serial_control_signal.start_signal.emit()
                    
                    # 舵机保持0度不动
                    if self.current_angle != 0:
                        self.servo_signal.log_signal.emit(f"🍓 好草莓检测 → 舵机归位到 0°")
                        self.servo_signal.log_signal.emit(f"🔧 调用 move_to_angle(0)...")
                        success = self.servo_controller.move_to_angle(0, delay=0.5)
                        self.servo_signal.log_signal.emit(f"🔧 move_to_angle 返回: {success}")
                        if success:
                            self.current_angle = 0
                            self.servo_signal.log_signal.emit(f"✓ 舵机已到达 0°")
                        else:
                            self.servo_signal.log_signal.emit(f"❌ 舵机移动到 0° 失败")
                    else:
                        self.servo_signal.log_signal.emit(f"🍓 好草莓检测 → 舵机已在 0°，保持不变")
                    self.last_detection_time = current_time
                    
                elif category == "badstrawberry":
                    # 检测到坏草莓，重置好草莓计数
                    if self.good_strawberry_count > 0:
                        self.servo_signal.log_signal.emit(f"⚠️ 检测到坏草莓，重置好草莓计数 (原计数: {self.good_strawberry_count})")
                        self.good_strawberry_count = 0
                        
                        # 停止串口发送（通过信号在主线程中执行）
                        self.serial_control_signal.stop_signal.emit()
                    
                    # 舵机转到45度
                    if self.current_angle != 45:
                        self.servo_signal.log_signal.emit(f"⚠️ 检测到坏草莓 (置信度: {confidence:.2f}) → 舵机转动到 45° 剔除")
                        self.servo_signal.log_signal.emit(f"🔧 调用 move_to_angle(45)...")
                        success = self.servo_controller.move_to_angle(45, delay=0.5)
                        self.servo_signal.log_signal.emit(f"🔧 move_to_angle 返回: {success}")
                        if success:
                            self.current_angle = 45
                            self.servo_signal.log_signal.emit(f"✓ 舵机已到达 45°")
                            # 延时后自动复位到0度
                            time.sleep(3.0)  # 等待3秒让舵机完成动作和草莓掉落
                            if self.servo_controller:
                                self.servo_signal.log_signal.emit("🔄 坏草莓已剔除，舵机复位到 0°")
                                self.servo_signal.log_signal.emit(f"🔧 调用 move_to_angle(0) 复位...")
                                success = self.servo_controller.move_to_angle(0, delay=0.5)
                                self.servo_signal.log_signal.emit(f"🔧 move_to_angle 返回: {success}")
                                if success:
                                    self.current_angle = 0
                                    self.servo_signal.log_signal.emit(f"✓ 舵机已复位到 0°")
                                else:
                                    self.servo_signal.log_signal.emit(f"❌ 舵机复位失败")
                        else:
                            self.servo_signal.log_signal.emit(f"❌ 舵机移动到 45° 失败")
                    else:
                        self.servo_signal.log_signal.emit(f"⚠️ 检测到坏草莓 (置信度: {confidence:.2f}) → 舵机已在 45°")
                    self.last_detection_time = current_time
                else:
                    self.servo_signal.log_signal.emit(f"⚠️ 未知类别: {category}")
                    
            except Exception as e:
                import traceback
                error_msg = f"❌ 舵机联动异常: {str(e)}\n{traceback.format_exc()}"
                self.servo_signal.log_signal.emit(error_msg)
        
        # 启动后台线程处理舵机控制
        thread = threading.Thread(target=servo_control_task, daemon=True)
        thread.start()

    def quit_application(self):
        """退出应用程序"""
        self.log_edit.append("👋 程序即将退出...")
        # 清理资源
        # 停止串口定时发送
        self.serial_timer.stop()
        
        self.stop_detect()
        
        # 关闭串口发送器
        if self.serial_sender:
            try:
                self.serial_sender.close_serial()
                self.log_edit.append(">>> 串口发送器已关闭")
            except Exception as e:
                print(f"关闭串口发送器时出错: {e}")
        
        # 关闭舵机
        if self.servo_controller:
            try:
                self.servo_controller.enable_pwm(False)
                self.servo_controller.unexport_pwm()
                self.log_edit.append(">>> 舵机已关闭")
            except Exception as e:
                print(f"关闭舵机时出错: {e}")
        
        # 退出程序
        from PyQt5.QtWidgets import QApplication
        QApplication.instance().quit()

    def closeEvent(self, event):
        """关闭窗口时释放资源"""
        # 停止串口定时发送
        self.serial_timer.stop()
        
        self.stop_detect()
        
        # 关闭串口发送器
        if self.serial_sender:
            try:
                self.serial_sender.close_serial()
                self.log_edit.append(">>> 串口发送器已关闭")
            except Exception as e:
                print(f"关闭串口发送器时出错: {e}")
        
        # 关闭舵机
        if self.servo_controller:
            try:
                self.servo_controller.enable_pwm(False)
                self.servo_controller.unexport_pwm()
                self.log_edit.append(">>> 舵机已关闭")
            except Exception as e:
                print(f"关闭舵机时出错: {e}")
        
        event.accept()

