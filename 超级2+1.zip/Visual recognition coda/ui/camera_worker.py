import cv2
import numpy as np
import time
from PyQt5.QtCore import QThread, pyqtSignal
from rknnlite.api import RKNNLite

# ===================== 全局配置（完全沿用你07脚本的参数） =====================
OBJ_THRESH = 0.25
NMS_THRESH = 0.45
IMG_SIZE = (640, 640)
CLASSES = ('goodstrawberry', 'badstrawberry', 'grape', 'guava', 'mango', 'orange', 'water melon')
# 修正模型路径 - 使用绝对路径或相对于项目根目录的路径
import os
_model_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(_model_dir, "yolov8.rknn")
# 尝试多个常见的摄像头设备索引（优先使用 video21）
CAMERA_INDICES = ['/dev/video21', '/dev/video0', '/dev/video1', '/dev/video2', 0]

# ===================== RKNN 模型容器（复用原代码） =====================
class RKNN_model_container():
    def __init__(self, model_path, target='rk3588'):
        rknn = RKNNLite()
        rknn.load_rknn(model_path)
        ret = rknn.init_runtime(core_mask=RKNNLite.NPU_CORE_0)
        if ret != 0:
            print("RKNN 初始化失败")
            exit(ret)
        self.rknn = rknn

    def run(self, inputs):
        if not isinstance(inputs, (list, tuple)):
            inputs = [inputs]
        return self.rknn.inference(inputs)

    def release(self):
        self.rknn.release()

# ===================== LetterBox 预处理（复用原代码） =====================
class Letter_Box_Info():
    def __init__(self, shape, new_shape, w_ratio, h_ratio, dw, dh, pad_color):
        self.origin_shape = shape
        self.new_shape = new_shape
        self.w_ratio = w_ratio
        self.h_ratio = h_ratio
        self.dw = dw
        self.dh = dh
        self.pad_color = pad_color

class COCO_test_helper():
    def __init__(self, enable_letter_box=True):
        self.enable_ltter_box = enable_letter_box
        self.letter_box_info_list = []

    def letter_box(self, im, new_shape, pad_color=(0,0,0)):
        shape = im.shape[:2]
        r = min(new_shape[0]/shape[0], new_shape[1]/shape[1])
        new_unpad = int(round(shape[1]*r)), int(round(shape[0]*r))
        dw, dh = new_shape[1]-new_unpad[0], new_shape[0]-new_unpad[1]
        dw /= 2
        dh /= 2
        if shape[::-1] != new_unpad:
            im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
        top, bottom = int(round(dh-0.1)), int(round(dh+0.1))
        left, right = int(round(dw-0.1)), int(round(dw+0.1))
        im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=pad_color)
        if self.enable_ltter_box:
            self.letter_box_info_list.append(Letter_Box_Info(shape, new_shape, r, r, dw, dh, pad_color))
        return im

    def get_real_box(self, box):
        bbox = box.copy()
        info = self.letter_box_info_list[-1]
        bbox[:,0] = np.clip((bbox[:,0]-info.dw)/info.w_ratio, 0, info.origin_shape[1])
        bbox[:,1] = np.clip((bbox[:,1]-info.dh)/info.h_ratio, 0, info.origin_shape[0])
        bbox[:,2] = np.clip((bbox[:,2]-info.dw)/info.w_ratio, 0, info.origin_shape[1])
        bbox[:,3] = np.clip((bbox[:,3]-info.dh)/info.h_ratio, 0, info.origin_shape[0])
        return bbox

# ===================== 后处理函数（完全复用你原代码） =====================
def filter_boxes(boxes, box_confidences, box_class_probs):
    box_confidences = box_confidences.reshape(-1)
    class_max_score = np.max(box_class_probs, axis=-1)
    classes = np.argmax(box_class_probs, axis=-1)
    _class_pos = np.where(class_max_score * box_confidences >= OBJ_THRESH)
    return boxes[_class_pos], classes[_class_pos], (class_max_score * box_confidences)[_class_pos]

def nms_boxes(boxes, scores):
    x, y = boxes[:,0], boxes[:,1]
    w, h = boxes[:,2]-boxes[:,0], boxes[:,3]-boxes[:,1]
    areas = w * h
    order = scores.argsort()[::-1]
    keep = []
    while order.size > 0:
        i = order[0]
        xx1 = np.maximum(x[i], x[order[1:]])
        yy1 = np.maximum(y[i], y[order[1:]])
        xx2 = np.minimum(x[i]+w[i], x[order[1:]]+w[order[1:]])
        yy2 = np.minimum(y[i]+h[i], y[order[1:]]+h[order[1:]])
        w1 = np.maximum(0.0, xx2 - xx1 + 1e-5)
        h1 = np.maximum(0.0, yy2 - yy1 + 1e-5)
        ovr = (w1*h1) / (areas[i] + areas[order[1:]] - w1*h1)
        order = order[np.where(ovr <= NMS_THRESH)[0] + 1]
        keep.append(i)
    return np.array(keep)

def dfl(position):
    x = np.array(position)
    n, c, h, w = x.shape
    p_num = 4
    mc = c // p_num
    y = x.reshape(n, p_num, mc, h, w)
    def softmax(arr, axis):
        exp_arr = np.exp(arr - np.max(arr, axis, keepdims=True))
        return exp_arr / np.sum(exp_arr, axis, keepdims=True)
    y = softmax(y, axis=2)
    acc_metrix = np.arange(mc, dtype=np.float32).reshape(1,1,mc,1,1)
    y = np.sum(y * acc_metrix, axis=2)
    return y

def box_process(position):
    grid_h, grid_w = position.shape[2:4]
    col, row = np.meshgrid(np.arange(grid_w), np.arange(grid_h))
    grid = np.concatenate((col.reshape(1,1,grid_h,grid_w), row.reshape(1,1,grid_h,grid_w)), axis=1)
    stride = np.array([IMG_SIZE[1]//grid_h, IMG_SIZE[0]//grid_w]).reshape(1,2,1,1)
    position = dfl(position)
    box_xy = grid + 0.5 - position[:,0:2,:,:]
    box_xy2 = grid + 0.5 + position[:,2:4,:,:]
    return np.concatenate((box_xy*stride, box_xy2*stride), axis=1)

def post_process(input_data):
    boxes, scores, classes_conf = [], [], []
    default_branch = 3
    pair_per_branch = len(input_data) // default_branch
    for i in range(default_branch):
        boxes.append(box_process(input_data[pair_per_branch*i]))
        classes_conf.append(input_data[pair_per_branch*i+1])
        scores.append(np.ones_like(input_data[pair_per_branch*i+1][:,:1,:,:], dtype=np.float32))
    def sp_flatten(_in):
        return _in.transpose(0,2,3,1).reshape(-1, _in.shape[1])
    boxes = np.concatenate([sp_flatten(v) for v in boxes])
    classes_conf = np.concatenate([sp_flatten(v) for v in classes_conf])
    scores = np.concatenate([sp_flatten(v) for v in scores])
    boxes, classes, scores = filter_boxes(boxes, scores, classes_conf)
    if len(boxes) == 0:
        return None, None, None
    nboxes, nclasses, nscores = [], [], []
    for c in set(classes):
        inds = np.where(classes == c)
        b, c_cls, s = boxes[inds], classes[inds], scores[inds]
        keep = nms_boxes(b, s)
        if len(keep) > 0:
            nboxes.append(b[keep])
            nclasses.append(c_cls[keep])
            nscores.append(s[keep])
    return np.concatenate(nboxes), np.concatenate(nclasses), np.concatenate(nscores)

# ===================== 摄像头推理线程 =====================
class CameraThread(QThread):
    frame_signal = pyqtSignal(object)   # 向外发送处理后的画面
    log_signal = pyqtSignal(str)         # 日志信号
    detection_signal = pyqtSignal(str, float)  # 检测结果信号(类别名称, 置信度)

    def __init__(self):
        super().__init__()
        self.running = False
        self.rknn_model = None
        self.cap = None
        self.helper = COCO_test_helper()

    def run(self):
        self.running = True
        # 初始化RKNN模型
        try:
            self.rknn_model = RKNN_model_container(MODEL_PATH)
            self.log_signal.emit("RKNN模型加载成功")
        except Exception as e:
            self.log_signal.emit(f"模型加载失败: {str(e)}")
            return

        # 打开摄像头 - 尝试多个设备索引
        self.cap = None
        camera_found = False
        
        for cam_idx in CAMERA_INDICES:
            try:
                self.log_signal.emit(f"正在尝试打开摄像头: {cam_idx}")
                self.cap = cv2.VideoCapture(cam_idx)
                if self.cap.isOpened():
                    # 测试是否能读取帧
                    ret, test_frame = self.cap.read()
                    if ret:
                        camera_found = True
                        self.log_signal.emit(f"✓ 摄像头 {cam_idx} 已成功打开")
                        break
                    else:
                        self.cap.release()
                        self.log_signal.emit(f"✗ 摄像头 {cam_idx} 无法读取帧")
                else:
                    self.log_signal.emit(f"✗ 摄像头 {cam_idx} 打开失败")
            except Exception as e:
                self.log_signal.emit(f"✗ 尝试摄像头 {cam_idx} 时出错: {str(e)}")
                if self.cap:
                    self.cap.release()
        
        if not camera_found or not self.cap.isOpened():
            self.log_signal.emit("❌ 错误：无法找到可用的摄像头设备")
            self.log_signal.emit("请检查：")
            self.log_signal.emit("1. 摄像头是否正确连接")
            self.log_signal.emit("2. 是否有摄像头访问权限")
            self.log_signal.emit("3. 摄像头是否被其他程序占用")
            self.running = False
            return
        
        # 设置摄像头参数
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.log_signal.emit(f"摄像头分辨率: {int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))}x{int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}")

        # 循环读取画面+推理
        frame_count = 0
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                frame_count += 1
                if frame_count > 10:  # 连续10次失败才报错
                    self.log_signal.emit("⚠ 摄像头读取帧失败，尝试重新连接...")
                    # 尝试重新打开摄像头
                    self.cap.release()
                    for cam_idx in CAMERA_INDICES:
                        try:
                            self.cap = cv2.VideoCapture(cam_idx)
                            if self.cap.isOpened():
                                ret, test_frame = self.cap.read()
                                if ret:
                                    self.log_signal.emit(f"✓ 摄像头重新连接成功: {cam_idx}")
                                    frame_count = 0
                                    break
                        except:
                            continue
                time.sleep(0.05)
                continue
            
            frame_count = 0  # 重置计数器

            # 预处理
            img = self.helper.letter_box(frame.copy(), IMG_SIZE)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = np.expand_dims(img, 0)

            # RKNN推理
            outputs = self.rknn_model.run([img])
            boxes, classes, scores = post_process(outputs)

            # 绘制检测框
            has_good_strawberry = False
            has_bad_strawberry = False
            best_bad_score = 0.0
            
            if boxes is not None:
                real_boxes = self.helper.get_real_box(boxes)
                for box, score, cl in zip(real_boxes, scores, classes):
                    x1, y1, x2, y2 = map(int, box)
                    cls_name = CLASSES[cl]
                    
                    # 计算面积（像素）
                    width = x2 - x1
                    height = y2 - y1
                    area = width * height
                    
                    # 颜色区分好坏草莓
                    if cls_name == "goodstrawberry":
                        color = (0, 0, 255)
                        has_good_strawberry = True
                    elif cls_name == "badstrawberry":
                        color = (0, 255, 0)
                        has_bad_strawberry = True
                        # 记录最高置信度的坏草莓
                        if score > best_bad_score:
                            best_bad_score = score
                    else:
                        color = (255, 0, 0)
                    
                    # 绘制矩形框
                    cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
                    
                    # 显示类别、置信度和面积
                    label = f"{cls_name} {score:.2f}"
                    area_label = f"Area: {area}"
                    
                    # 在框上方显示类别和置信度
                    cv2.putText(frame, label, (x1,y1-8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
                    # 在框下方显示面积
                    cv2.putText(frame, area_label, (x1,y2+20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # 发送检测结果给UI进行舵机控制
            # 优先级：好草莓优先，如果没有好草莓但有坏草莓则触发舵机
            if has_good_strawberry:
                self.detection_signal.emit("goodstrawberry", 1.0)
                self.log_signal.emit("📤 发送信号: 好草莓检测")
            elif has_bad_strawberry:
                self.detection_signal.emit("badstrawberry", best_bad_score)
                self.log_signal.emit(f"📤 发送信号: 坏草莓检测 (置信度: {best_bad_score:.2f})")

            # 发送画面到UI
            self.frame_signal.emit(frame)
            time.sleep(0.02)

        # 释放资源
        if self.cap:
            self.cap.release()
        if self.rknn_model:
            self.rknn_model.release()
        self.log_signal.emit("摄像头与模型已关闭")

    def stop(self):
        self.running = False
        self.wait()

