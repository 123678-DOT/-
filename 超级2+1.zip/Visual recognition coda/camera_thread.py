import cv2
import time
from PyQt5.QtCore import QThread, pyqtSignal
from utils.rk3588_ai_infer import RK3588AIModel  # RK3588 AI推理封装

class CameraThread(QThread):
    frame_signal = pyqtSignal(object)  # 发送摄像头帧
    error_signal = pyqtSignal(str)     # 发送错误信息

    def __init__(self, camera_idx=0, model_path="./models/strawberry_model.rknn"):
        super().__init__()
        self.camera_idx = camera_idx
        self.model_path = model_path
        self.is_running = False
        self.cap = None
        # 初始化RK3588 AI模型（草莓分选识别）
        self.ai_model = RK3588AIModel(model_path)

    def run(self):
        """线程主逻辑：读取摄像头 + AI识别"""
        self.is_running = True
        self.cap = cv2.VideoCapture(self.camera_idx)
        # RK3588摄像头参数配置（根据实际调整）
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.cap.set(cv2.CAP_PROP_FPS, 30)

        if not self.cap.isOpened():
            self.error_signal.emit("摄像头打开失败，请检查硬件连接")
            self.is_running = False
            return

        while self.is_running:
            ret, frame = self.cap.read()
            if not ret:
                self.error_signal.emit("摄像头帧读取失败")
                break

            # 调用RK3588 AI模型进行草莓识别（大小/成熟度/瑕疵）
            frame = self.ai_model.infer(frame)  # 帧上叠加识别框/评分

            # 发送处理后的帧到UI
            self.frame_signal.emit(frame)
            time.sleep(0.01)  # 控制帧率

    def stop(self):
        """停止线程并释放摄像头"""
        self.is_running = False
        if self.cap:
            self.cap.release()
        self.wait()

        